const express = require('express');
const session = require('express-session'); //maneja sesiones
const MySQLStore = require('express-mysql-session')(session); //almacena sesiones en MySQL
const bodyParser = require('body-parser'); //maneja los datos de los formularios
const app = express();
const indexRoutes = require('./routes/index'); // Importa las rutas de index.js
const authRoutes = require('./routes/auth'); // Importa las rutas de auth.js

// Configuración para almacenar las sesiones
const options = {
    host: 'localhost',
    user: 'root',
    password: 'fans',
    database: 'burgerweek'
};

const sessionStore = new MySQLStore(options);

// Configuración de sesión con almacenamiento en MySQL
app.use(session({
    key: 'session_cookie_name',
    secret: 'your_secret_key',
    store: sessionStore, // Almacena las sesiones
    resave: false, // No vuelve a guardar si no ha habido cambios
    saveUninitialized: false, // No guarda una sesión sin inicializar
    cookie: {
        maxAge: 24 * 60 * 60 * 1000 // tiempo de 24 horas
    }
}));

// Configuraciones básicas
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }))

// Rutas
app.use('/', indexRoutes); 
app.use('/', authRoutes);

// Ruta para la página principal
app.get('/', (req, res) => {
    res.render('index');
});

app.listen(3000, () => {
    console.log('Servidor iniciado en http://localhost:3000');
});
