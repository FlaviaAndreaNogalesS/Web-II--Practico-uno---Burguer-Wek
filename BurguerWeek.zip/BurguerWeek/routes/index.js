const express = require('express');
const router = express.Router(); 
const db = require('../database');

// Middleware para verificar si el usuario está autenticado
function checkAuthenticated(req, res, next) {
    if (req.session.user) { // Si existe, permite continuar
        return next();
    }
    return res.redirect('/login'); //si no, va a login
}

// Ruta para mostrar el catálogo de restaurantes (requiere autenticación)
router.get('/catalog', checkAuthenticated, (req, res) => {
    // Consulta para obtener todos los restaurantes
    db.query('SELECT * FROM restaurants', (err, results) => {
        if (err) {
            console.error('Error fetching restaurants:', err);
            return res.status(500).send('Error al cargar los restaurantes.');
        }
        // Renderiza la vista
        res.render('catalog', { restaurants: results, user: req.session.user });
    });
});

// Ruta para mostrar las hamburguesas de un restaurante específico
router.get('/restaurants/:id/burgers', (req, res) => {
    const restaurantId = req.params.id; // Obtiene el id del restaurante

    // Consulta para obtener las hamburguesas del restaurante
    db.query('SELECT * FROM burgers WHERE restaurant_id = ?', [restaurantId], (err, results) => {
        if (err) {
            console.error('Error fetching burgers:', err);
            return res.status(500).send('Error al cargar las hamburguesas.');
        }

        // Consulta para obtener los detalles del restaurante
        db.query('SELECT * FROM restaurants WHERE id = ?', [restaurantId], (err2, restaurant) => {
            if (err2 || restaurant.length === 0) {
                console.error('Error fetching restaurant:', err2);
                return res.status(500).send('Error al cargar el restaurante.');
            }

            // Renderiza la vista
            res.render('burgers', { burgers: results, restaurant: restaurant[0], user: req.session.user });
        });
    });
});

// Ruta para mostrar los reviews de una hamburguesa específica
router.get('/burgers/:id/reviews', (req, res) => {
    const burgerId = req.params.id; // Obtiene el id de la hamburguesa

    // Consulta para obtener los reviews de la hamburguesa
    db.query('SELECT reviews.*, users.username FROM reviews JOIN users ON reviews.user_id = users.id WHERE burger_id = ?', [burgerId], (err, reviews) => {
        if (err) { 
            console.error('Error fetching reviews:', err);
            return res.status(500).send('Error al cargar las reseñas.');
        }

        // Consulta para obtener los detalles de la hamburguesa
        db.query('SELECT * FROM burgers WHERE id = ?', [burgerId], (err2, burger) => {
            if (err2 || burger.length === 0) { 
                console.error('Error fetching burger:', err2);
                return res.status(500).send('Error al cargar la hamburguesa.');
            }

            // Renderiza la vista pasando los resultados
            res.render('reviews', { reviews: reviews, burger: burger[0], user: req.session.user });
        });
    });
});

// Ruta para manejar la creación de un nuevo review
router.post('/burgers/:id/reviews', (req, res) => {
    const burgerId = req.params.id; // Obtiene el id de la hamburguesa
    const { rating, review_text } = req.body; // Desestructura los valores
    const userId = req.session.user.id; // Obtiene el id del usuario

    // Inserta el review en la base de datos
    db.query('INSERT INTO reviews (burger_id, user_id, rating, review_text) VALUES (?, ?, ?, ?)', 
    [burgerId, userId, rating, review_text], (err, result) => {
        if (err) { 
            console.error('Error inserting review:', err);
            return res.status(500).send('Error al dejar el review.');
        }

        // como pa refrescar
        res.redirect(`/burgers/${burgerId}/reviews`);
    });
});

// Ruta para eliminar un review
router.post('/reviews/:id/delete', (req, res) => {
    const reviewId = req.params.id;
    const userId = req.session.user.id; // ID del usuario

    // Asegura de que solo el autor pueda eliminar su propio review
    db.query('DELETE FROM reviews WHERE id = ? AND user_id = ?', [reviewId, userId], (err, result) => {
        if (err) {
            console.error('Error deleting review:', err);
            return res.status(500).send('Error al eliminar el review.');
        }
        res.redirect('back'); // Redirigir a la pagina de reviews
    });
});

// Ruta para mostrar el formulario de edición de un review
router.get('/reviews/:id/edit', (req, res) => {
    const reviewId = req.params.id;
    const userId = req.session.user.id;

    // Obtener el review para mostrarlo en el formulario de edición
    db.query('SELECT * FROM reviews WHERE id = ? AND user_id = ?', [reviewId, userId], (err, results) => {
        if (err || results.length === 0) {
            console.error('Error fetching review:', err);
            return res.status(500).send('Error al cargar el review.');
        }

        res.render('edit_review', { review: results[0], user: req.session.user });
    });
});


// Ruta para actualizar un review
router.post('/reviews/:id/edit', (req, res) => {
    const reviewId = req.params.id;
    const userId = req.session.user.id;
    const { rating, review_text } = req.body;

    // Actualizar el review
    db.query('UPDATE reviews SET rating = ?, review_text = ? WHERE id = ? AND user_id = ?', 
    [rating, review_text, reviewId, userId], (err, result) => {
        if (err) {
            console.error('Error updating review:', err);
            return res.status(500).send('Error al actualizar el review.');
        }
        res.redirect(`/burgers/${req.body.burger_id}/reviews`); // vuelve a la página de reviews
    });
});

// Ruta para listar restaurantes
router.get('/restaurants/manage', (req, res) => {
    db.query('SELECT * FROM restaurants', (err, results) => {
        if (err) {
            console.error('Error fetching restaurants:', err);
            return res.status(500).send('Error al cargar los restaurantes.');
        }
        res.render('manage_restaurants', { restaurants: results, user: req.session.user });
    });
});

// Ruta para mostrar formulario de agregar restaurante
router.get('/restaurants/add', (req, res) => {
    res.render('add_restaurant', { user: req.session.user });
});

// Ruta para agregar restaurante
router.post('/restaurants/add', (req, res) => {
    const { name, description, image_url } = req.body;
    db.query('INSERT INTO restaurants (name, description, image_url) VALUES (?, ?, ?)', [name, description, image_url], (err, result) => {
        if (err) {
            console.error('Error adding restaurant:', err);
            return res.status(500).send('Error al agregar el restaurante.');
        }
        res.redirect('/restaurants/manage');
    });
});

// Ruta para eliminar restaurante
router.post('/restaurants/:id/delete', (req, res) => {
    const restaurantId = req.params.id;
    db.query('DELETE FROM restaurants WHERE id = ?', [restaurantId], (err, result) => {
        if (err) {
            console.error('Error deleting restaurant:', err);
            return res.status(500).send('Error al eliminar el restaurante.');
        }
        res.redirect('/restaurants/manage');
    });
});

// Ruta para mostrar formulario de edición
router.get('/restaurants/:id/edit', (req, res) => {
    const restaurantId = req.params.id;
    db.query('SELECT * FROM restaurants WHERE id = ?', [restaurantId], (err, result) => {
        if (err || result.length === 0) {
            console.error('Error fetching restaurant:', err);
            return res.status(500).send('Error al cargar el restaurante.');
        }
        res.render('edit_restaurant', { restaurant: result[0], user: req.session.user });
    });
});

// Ruta para actualizar restaurante
router.post('/restaurants/:id/edit', (req, res) => {
    const restaurantId = req.params.id;
    const { name, description, image_url } = req.body;
    db.query('UPDATE restaurants SET name = ?, description = ?, image_url = ? WHERE id = ?', 
    [name, description, image_url, restaurantId], (err, result) => {
        if (err) {
            console.error('Error updating restaurant:', err);
            return res.status(500).send('Error al actualizar el restaurante.');
        }
        res.redirect('/restaurants/manage');
    });
});


module.exports = router;
