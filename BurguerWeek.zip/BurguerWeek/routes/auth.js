const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs'); // encripta las contraseñas
const db = require('../database'); // conecta con la base de datos

// Ruta para mostrar el formulario de registro
router.get('/register', (req, res) => {
    res.render('register');
});

// Ruta para manejar el registro
router.post('/register', async (req, res) => {
    const { username, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10); // Encripta la contraseña

    // Inserta los datos en la base de datos
    db.query('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', 
    [username, email, hashedPassword], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Error al registrar el usuario.');
        }
        res.redirect('/login'); // registro exitoso va a login
    });
});

// Ruta para mostrar el formulario de login
router.get('/login', (req, res) => {
    res.render('login');
});

// Ruta para manejar el login
router.post('/login', (req, res) => {
    const { email, password } = req.body;

    // Busca al usuario en la base de datos
    db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Error al iniciar sesión.');
        }

        if (results.length === 0) {
            return res.render('login', { error: 'Usuario no encontrado.' });
        }

        const user = results[0]; // Obtiene el usuario
        const match = await bcrypt.compare(password, user.password); // Compara la contraseña

        if (!match) { // contraseñas incorrecta
            return res.render('login', { error: 'Contraseña incorrecta.' });
        }

        // Si coinciden
        req.session.user = user;
        return res.redirect('/catalog'); // Redirige al catálogo
    });
});

// Ruta para manejar el logout
router.get('/logout', (req, res) => {
    // Destruye la sesión del usuario y redirige al formulario de login
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).send('Error al cerrar sesión.');
        }
        res.redirect('/login'); // Redirige a login
    });
});

module.exports = router;
