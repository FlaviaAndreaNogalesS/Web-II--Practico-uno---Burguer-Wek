//conexión a mysql
const mysql = require('mysql2');

//datos de mi base de datos
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'fans',
    database: 'burgerweek'
});

//pa ver si conecta
connection.connect((err) => {
    if (err) {
        //no
        console.error('Error connecting to the database:', err.stack);
        return;
    }
    console.log('Connected to the database.'); //si
});

module.exports = connection;
